<?php $__env->startSection('judul', 'Daftar'); ?>

<?php $__env->startSection('content'); ?>
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-b-160 p-t-50">
				<form class="login100-form validate-form" method="POST" action="<?php echo e(route('register')); ?>">
					<?php echo csrf_field(); ?>
					<div class="login100-form-avatar">
						<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/avatar100.png')); ?>" alt="AVATAR"></a>
					</div>
					<span class="login100-form-title p-t-20 p-b-45">
					</span>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Name is required">
						<input id="name" class="input100 <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="name" placeholder="Nama Lengkap" >
						<span class="focus-input100">asd</span>
						<span class="symbol-input100">
							<i class="fa fa-user-circle"></i>
						</span>
					</div>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Email is required">
						<input id="email"  class="input100 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="email" placeholder="Email">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope"></i>
						</span>
					</div>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input id="password" class="input100 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="new-password" type="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100" type="password" name="password_confirmation" placeholder="Konfirmasi Password" id="password-confirm" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="new-password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>
					<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
					<div class="alert alert-danger alert-dismissible fade show m-auto" role="alert">
						<?php echo e($message); ?>

						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
					<div class="alert alert-danger alert-dismissible fade show m-auto" role="alert">
						<?php echo e($message); ?>

						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
					<div class="alert alert-danger alert-dismissible fade show m-auto" role="alert">
						<?php echo e($message); ?>

						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn" type="submit">
							<?php echo e(__('Daftar')); ?>

						</button>
					</div>
					<div class="text-center w-full p-t-23">
						
					<a href="<?php echo e(url('/')); ?>" class="txt1 float-left" style="color:white" onMouseOver="this.style.color='#0F0'" onMouseOut="this.style.color='#fff'">
                        <?php echo e(__('Kembali ke Home')); ?>

						</a>
						<a href="<?php echo e(url('/login')); ?>" class="txt1 float-right"  style="color:white" onMouseOver="this.style.color='#0F0'" onMouseOut="this.style.color='#fff'">
									<?php echo e(__('Masuk')); ?>

						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\roboinvestasi\resources\views/auth/register.blade.php ENDPATH**/ ?>