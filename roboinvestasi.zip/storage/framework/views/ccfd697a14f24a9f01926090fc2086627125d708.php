<?php $__env->startSection('judul', 'login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-b-160 p-t-50">
	<?php if(session('status')): ?>
                <div class="alert alert-danger alert-dismissible " role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
                <?php echo e(session('status')); ?>

                </div>
			<?php endif; ?>
			
				<form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
					<div class="login100-form-avatar">
						<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/avatar100.png')); ?>" alt="AVATAR"></a>
					</div>

					<span class="login100-form-title p-t-20 p-b-45">
					</span>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "email is required">
						<input class="input100 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope"></i>
						</span>
					</div>
					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="password" name="password" placeholder="Password" required autocomplete="current-password" class="form-control" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>
					<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
					<div class="alert alert-danger alert-dismissible fade show m-auto" role="alert">
						<?php echo e($message); ?>

						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
					<div class="alert alert-danger alert-dismissible fade show m-auto" role="alert">
						<?php echo e($message); ?>

						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

					<!-- <div class="text-center checkbox w-full p-t-10 text-white">
						<label style="font-size: 1em">
						<input type="checkbox" value="" name="remember"  <?php echo e(old('remember') ? 'checked' : ''); ?>>
						<span class="cr"><i class="cr-icon fa fa-check"></i></span>
						<?php echo e(__('Remember Me')); ?>

						</label>
					</div> -->

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn" type="submit">
                            <?php echo e(__('Masuk')); ?>

						</button>
					</div>
					<div class="text-center w-full p-t-23">
						<a href="<?php echo e(url('/')); ?>" class="txt1 float-left" style="color:white" onMouseOver="this.style.color='#0F0'" onMouseOut="this.style.color='#fff'">
                        <?php echo e(__('Kembali ke Home')); ?>

						</a>

						<a href="<?php echo e(url('/register')); ?>" class="txt1 float-right txt-white" style="color:white" onMouseOver="this.style.color='#0F0'" onMouseOut="this.style.color='#fff'">
							<?php echo e(__('Belum punya akun? Daftar')); ?>

						</a>
					</div>
					<!-- <div class="w-full">
						<a href="<?php echo e(route('login.provider', 'google')); ?>" class="btn btn-danger"><?php echo e(__('Google Sign in')); ?></a>
					</div> -->
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\roboinvestasi\resources\views/auth/login.blade.php ENDPATH**/ ?>