<?php $__env->startSection('title', 'PilHam'); ?>
<?php $__env->startSection('breadcrumb', 'PilHam'); ?>
<?php $__env->startSection('title2', 'Robo Pilih Saham'); ?>

<?php $__env->startSection('page'); ?>
  <div class="page-section">
    <div class="container">
            <div class="d-flex justify-content-center">
              <img class="img-fluid" src="<?php echo e(asset('assets/img/avatar100.png')); ?>" alt="">
            </div>
            <div class="body">
            <?php if($mode =="input"): ?>
              <div class="input-group-addon mb-3"> 
                  <a href="javascript:void(0)" class="btn btn-success addMore"><i class="fas fa-plus"></i></a>
              </div>
              <form method="post" action="<?php echo e(url('robopilham')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group fieldGroup">
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="text" name="name[]" class="form-control" placeholder="Kode Saham" required/>
                    </div>
                  </div>
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="npm[]" class="form-control" placeholder="Net Profit Margin (NPM) contoh: 10,2" required/>
                    </div>
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="roa[]" class="form-control" placeholder="Return on Assets (ROA) contoh: 1,2" required/>
                    </div>
                  </div>
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="roe[]" class="form-control" placeholder="Return on Equity (ROE) contoh: 8,2" required/>
                    </div>
                    <div class="form-group col-md-6">
                      <input type="number" name="eps[]" class="form-control" placeholder="Earning Per Share (EPS) contoh: 200" required/>
                    </div>
                  </div>
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="per[]" class="form-control" placeholder="Price Earning Ratio (PER) contoh: 2,2" required/>
                    </div>
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="pbvr[]" class="form-control" placeholder="price book value Ratio (PBVR) contoh: 10,2" required/>
                    </div>
                  </div>
                </div>
                <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Rangkingkan"/>
              </form>

              <div class="form-group fieldGroupCopy" style="display: none;">
                  <div class="input-group-addon mb-2"> 
                      <a href="javascript:void(0)" class="btn btn-danger remove"><i class="fas fa-trash"></i></a>
                  </div>
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="text" name="name[]" class="form-control" placeholder="Kode Saham" required/>
                    </div>
                  </div>
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="npm[]" class="form-control" placeholder="Net Profit Margin (NPM) contoh: 10,2" required/>
                    </div>
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="roa[]" class="form-control" placeholder="Return on Assets (ROA) contoh: 1,2" required/>
                    </div>
                  </div>
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="roe[]" class="form-control" placeholder="Return on Equity (ROE) contoh: 8,2" required/>
                    </div>
                    <div class="form-group col-md-6">
                      <input type="number" name="eps[]" class="form-control" placeholder="Earning Per Share (EPS) contoh: 200" required/>
                    </div>
                  </div>
                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="per[]" class="form-control" placeholder="Price Earning Ratio (PER) contoh: 2,2" required/>
                    </div>
                    <div class="form-group col-md-6">
                      <input type="number" step="0.01" min="0" name="pbvr[]" class="form-control" placeholder="price book value Ratio (PBVR) contoh: 10,2" required/>
                    </div>
                  </div>
                  </div>
              </div>
              <?php elseif($mode == "hasil"): ?>
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Nilai</th>
                  </tr>
                </thead>
                <tbody>
                <?php for($a = 0; $a < count($total); $a++): ?>
                <tr>
                    <th scope="row"><?php echo e($a+1); ?></th>
                    <td><?php echo e($nama[$a]); ?></td>
                    <td><?php echo e($total[$a]); ?></td>
                  </tr>
                <?php endfor; ?>
                </tbody>
              </table>
              <div class="d-flex justify-content-center">
                <a href="<?php echo e(url('alat/pilham')); ?>" class="btn btn-primary">Hitung Yang lain</a>
              </div>
              <?php endif; ?>
            </div>
    </div> <!-- .container -->
  </div> <!-- .page-section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\roboinvestasi\resources\views/tools/pilham.blade.php ENDPATH**/ ?>