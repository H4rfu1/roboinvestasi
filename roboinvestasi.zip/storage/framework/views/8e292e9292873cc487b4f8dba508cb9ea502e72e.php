<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH F:\aplikasi\xampp\htdocs\roboinvestasi\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>