<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('page'); ?>

<div class="page-section">
    <div class="container">
        <div class="row">
            <div class="col-sm-10">
                <form action="#" class="form-search-blog">
                    <!-- <div class="input-group">
                    <div class="input-group-prepend">
                        <select id="categories" class="custom-select bg-light">
                        <option>All Categories</option>
                        <option value="travel">Travel</option>
                        <option value="lifestyle">LifeStyle</option>
                        <option value="healthy">Healthy</option>
                        <option value="food">Food</option>
                        </select>
                    </div>
                    <input type="text" class="form-control" placeholder="Enter keyword..">
                    </div> -->
                </form>
            </div>
            <div class="col-sm-2 text-sm-right">
                <a class="btn btn-secondary" href="/buat" >Buat artikel</a>
            </div>
        </div>

        <div class="row my-5">
            <form action="<?php echo e(url('/postBuat')); ?>" method="post" enctype="multipart/form-data" style="width: 50%; margin: 0 25% 0 25%;">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Judul</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Isi judul" name="judul">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Penulis</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Nama penulis" name="penulis">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Isi blog</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="isi"></textarea>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Foto</label>
                    <input type="file" class="form-control" id="exampleFormControlInput1" placeholder="Isi judul" name="foto">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Tambah</button>
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-danger">Batal</a>
                </div>
            </form>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.temp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\roboinvestasi\resources\views/formBlog.blade.php ENDPATH**/ ?>