<h1>Aktifkan newletter anda {{$to_email}}</h1>
<a href="{{url('aktifkan/'.$aktivasi)}}">klik disini</a>
<p>atau copy link berikut</p>
<a href="{{url('aktifkan/'.$aktivasi)}}">{{url('aktifkan/'.$aktivasi)}}</a>